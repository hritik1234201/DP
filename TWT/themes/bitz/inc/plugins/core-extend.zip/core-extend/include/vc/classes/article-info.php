<?php
class WPBakeryShortCode_Mnky_Article_Info extends WPBakeryShortCode {

}