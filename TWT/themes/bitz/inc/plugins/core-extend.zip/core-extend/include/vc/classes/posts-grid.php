<?php
class WPBakeryShortCode_Mnky_Posts_Grid extends WPBakeryShortCode {
    // public function outputTitle($title) {
        // return '';
    // }
}