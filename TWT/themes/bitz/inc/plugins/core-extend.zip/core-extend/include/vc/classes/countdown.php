<?php

class WPBakeryShortCode_Mnky_Countdown extends WPBakeryShortCode {

}